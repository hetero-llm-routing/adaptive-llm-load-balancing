"""Analysis of the experiment runs (task #53): the metrics of Section 3.3, Eqs. (3) to (9), per run,
then means with 95% confidence intervals over the seeds and paired comparisons between strategies.

    python analysis/analyze.py --runs results/runs --out results/analysis [--baseline round_robin]
    python analysis/analyze.py --decision-time --out results/analysis      # Eq. for D, RQ3

Input: the files bench/run_matrix.py writes for every run: <run>_meta.json, the router CSV named
in the meta file, <run>_client.csv and <run>_energy.json (infra/attribute_energy.py).

Per run (requests that arrive in the first warmup_s seconds are left out):
  TTFT  f - a                                   Eq. (3)  mean, p50, p95, p99 (ms)
  TPOT  (c - f) / (O - 1)                       Eq. (4)  mean, p95 (ms)
  X     sum O / T                               Eq. (5)  tokens/s; T = first arrival to last completion
  U_j   |B_j| / T                               Eq. (6)  busy-time ratio: union of [a, c] of the node's requests
  L     max_j U_j / mean_j U_j - 1              Eq. (7)  load imbalance
  e_j   E_j / sum O on node j                   Eq. (8)  J/token per node, from the energy file
  e     sum_j E_j / sum O                       Eq. (9)  cluster J/token
  failed share of the scheduled requests that did not finish (client log)

Aggregation: for every (experiment, workload, rho, strategy) the mean over seeds with a 95%
t-interval. Paired comparison: for every strategy against the baseline and against the best
strategy of the cell, the per-seed differences (same requests, same arrival times), their mean,
a 95% bootstrap interval (10,000 resamples) and the share of resamples on the other side of zero.
"""
import argparse, csv, glob, json, math, random, statistics, sys, time
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
METRICS = ["ttft_mean_ms", "ttft_p50_ms", "ttft_p95_ms", "ttft_p99_ms", "tpot_mean_ms", "tpot_p95_ms",
           "e2e_p50_ms", "e2e_p95_ms", "throughput_tps", "imbalance_L", "j_per_token", "failed_share"]
LOWER_IS_BETTER = {m: m not in ("throughput_tps",) for m in METRICS}
T95 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262, 10: 2.228}


def pct(v, q):
    """Percentile by linear interpolation (numpy's default)."""
    if not v:
        return float("nan")
    v = sorted(v)
    k = (len(v) - 1) * q
    lo, hi = math.floor(k), math.ceil(k)
    return v[lo] + (v[hi] - v[lo]) * (k - lo)


def union_length(intervals):
    total, end = 0.0, -math.inf
    for a, b in sorted(intervals):
        if b <= end:
            continue
        total += b - max(a, end)
        end = b
    return total


def run_metrics(meta_path):
    meta = json.loads(Path(meta_path).read_text())
    d = Path(meta_path).parent
    rid = meta["run_id"]
    rows = list(csv.DictReader(open(d / meta["requests_csv"])))
    t_start = float(meta["start_ts"]) + float(meta.get("warmup_s", 30))
    reqs = []
    for r in rows:
        a = float(r["arrival_ts"])
        if a < t_start:
            continue
        ttft, e2e, n = float(r["ttft_ms"]) / 1000, float(r["e2e_ms"]) / 1000, int(float(r["output_len"] or 0))
        reqs.append({"gpu": r["gpu"], "a": a, "f": a + ttft, "c": a + e2e, "O": n,
                     "tpot": (e2e - ttft) / (n - 1) if n > 1 else None})
    out = {k: meta.get(k) for k in ("experiment", "workload", "rho", "seed", "strategy", "run_id")}
    if not reqs:
        return out
    ttft = [(r["f"] - r["a"]) * 1000 for r in reqs]
    tpot = [r["tpot"] * 1000 for r in reqs if r["tpot"] is not None]
    e2e = [(r["c"] - r["a"]) * 1000 for r in reqs]
    T = max(r["c"] for r in reqs) - min(r["a"] for r in reqs)
    nodes = sorted({r["gpu"] for r in reqs})
    energy = {}
    ef = d / f"{rid}_energy.json"
    if ef.exists():
        energy = json.loads(ef.read_text())
        nodes = sorted(set(nodes) | set(energy.get("nodes", {})))
    U = {j: union_length([(r["a"], r["c"]) for r in reqs if r["gpu"] == j]) / T for j in nodes}
    mean_u = statistics.mean(U.values())
    sched = failed = 0
    cf = d / f"{rid}_client.csv"
    if cf.exists():
        for r in csv.DictReader(open(cf)):
            if float(r["scheduled_s"]) >= float(meta.get("warmup_s", 30)):
                sched += 1
                failed += r["error"] != "" or r["status"] != "200"
    out.update(n=len(reqs), ttft_mean_ms=statistics.mean(ttft), ttft_p50_ms=pct(ttft, .5), ttft_p95_ms=pct(ttft, .95),
               ttft_p99_ms=pct(ttft, .99), tpot_mean_ms=statistics.mean(tpot) if tpot else float("nan"),
               tpot_p95_ms=pct(tpot, .95), e2e_p50_ms=pct(e2e, .5), e2e_p95_ms=pct(e2e, .95),
               throughput_tps=sum(r["O"] for r in reqs) / T if T > 0 else float("nan"),
               imbalance_L=max(U.values()) / mean_u - 1 if mean_u > 0 else float("nan"),
               j_per_token=(energy.get("cluster") or {}).get("j_per_token", float("nan")),
               failed_share=failed / sched if sched else 0.0)
    for j in nodes:
        out[f"U_{j}"] = U[j]
        out[f"share_{j}"] = sum(1 for r in reqs if r["gpu"] == j) / len(reqs)
        out[f"jpt_{j}"] = ((energy.get("nodes") or {}).get(j) or {}).get("j_per_token")
    return out


def ci95(v):
    v = [x for x in v if x is not None and not math.isnan(x)]
    if not v:
        return float("nan"), float("nan")
    m = statistics.mean(v)
    if len(v) < 2:
        return m, float("nan")
    return m, T95.get(len(v) - 1, 1.96) * statistics.stdev(v) / math.sqrt(len(v))


def paired_bootstrap(diffs, n=10000, seed=0):
    rng = random.Random(seed)
    k = len(diffs)
    means = sorted(statistics.mean(rng.choice(diffs) for _ in range(k)) for _ in range(n))
    m = statistics.mean(diffs)
    other_side = sum(1 for x in means if (x >= 0) != (m >= 0)) / n
    return m, means[int(0.025 * n)], means[int(0.975 * n) - 1], other_side


def write_csv(path, rows):
    keys = []
    for r in rows:
        keys += [k for k in r if k not in keys]
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); w.writerows(rows)


def analyze(runs_dir, out, baseline):
    metas = sorted(glob.glob(str(Path(runs_dir) / "**" / "*_meta.json"), recursive=True))
    per_run = [run_metrics(m) for m in metas]
    per_run = [r for r in per_run if r.get("n")]
    write_csv(out / "runs.csv", per_run)
    cells = defaultdict(lambda: defaultdict(dict))          # cell -> strategy -> seed -> row
    for r in per_run:
        cells[(r["experiment"], r["workload"], r["rho"])][r["strategy"]][r["seed"]] = r
    summary, paired = [], []
    for cell, strat in sorted(cells.items(), key=lambda x: str(x[0])):
        for s, seeds in sorted(strat.items()):
            row = {"experiment": cell[0], "workload": cell[1], "rho": cell[2], "strategy": s, "seeds": len(seeds)}
            for m in METRICS:
                row[m], row[m + "_ci95"] = ci95([seeds[k].get(m) for k in seeds])
            summary.append(row)
        for m in ("ttft_p95_ms", "e2e_p95_ms", "tpot_mean_ms", "throughput_tps", "imbalance_L", "j_per_token"):
            means = {s: statistics.mean(v[k][m] for k in v) for s, v in strat.items()}
            best = (min if LOWER_IS_BETTER[m] else max)(means, key=means.get)
            for ref in {baseline, best}:
                if ref not in strat:
                    continue
                for s in strat:
                    if s == ref:
                        continue
                    common = sorted(set(strat[s]) & set(strat[ref]))
                    if len(common) < 2:
                        continue
                    diffs = [strat[s][k][m] - strat[ref][k][m] for k in common]
                    mean, lo, hi, p = paired_bootstrap(diffs)
                    paired.append({"experiment": cell[0], "workload": cell[1], "rho": cell[2], "metric": m,
                                   "strategy": s, "reference": ref, "seeds": len(common), "mean_diff": mean,
                                   "rel_diff": mean / statistics.mean(strat[ref][k][m] for k in common),
                                   "ci95_low": lo, "ci95_high": hi, "p_other_side": p})
    write_csv(out / "summary.csv", summary)
    if paired:
        write_csv(out / "paired.csv", paired)
    print(f"{len(per_run)} runs, {len(summary)} strategy cells, {len(paired)} paired comparisons -> {out}")
    show = ["ttft_p95_ms", "e2e_p95_ms", "throughput_tps", "imbalance_L", "j_per_token"]
    for r in summary:
        print(f"{r['experiment']:8s} {r['workload']:6s} {r['rho']!s:4s} {r['strategy']:14s} n={r['seeds']} "
              + " ".join(f"{m}={r[m]:.3g}" for m in show))


def decision_time(out, nodes_list=(3, 8, 16), n=2000):
    """Decision overhead D (RQ3): time of choose_gpu on node states drawn like the real cluster."""
    sys.path.insert(0, str(ROOT))
    import importlib
    from strategies.base import Request, GpuState
    prof = {}
    for f in sorted((ROOT / "results" / "profiles").glob("*.json")):
        p = json.loads(f.read_text())
        prof[f.stem] = {"speed_tps": p["speed_tps"], "prefill_tps": p["prefill_tps"],
                        "speed_by_n": [p["decode_by_concurrency"][str(k)]["total_tps"] for k in (1, 2, 3, 4)],
                        "power_by_n": [p["power"][f"decode_{k}"]["mean_w"] for k in (1, 2, 3, 4)],
                        "idle_w": p["power"]["idle"]["mean_w"]}
    types = list(prof.values())
    rows = []
    for name in sorted(p.stem for p in (ROOT / "strategies").glob("*.py")):
        if name in ("__init__", "base", "length_predictor", "mock_sim"):
            continue
        try:
            mod = importlib.import_module("strategies." + name)
        except Exception as e:
            print("skip", name, e); continue
        if not hasattr(mod, "choose_gpu"):
            continue
        for k in nodes_list:
            rng = random.Random(k)
            if hasattr(mod, "reset"):
                mod.reset()
            times = []
            for i in range(n):
                states = {f"n{j}": GpuState(queue_len=rng.randint(0, 3), running=rng.randint(0, 4), kv_usage=rng.random(),
                                            extra=dict(types[j % len(types)], inflight=rng.randint(0, 6))) for j in range(k)}
                req = Request(request_id=str(i), prompt_len=rng.randint(20, 6000), req_type=rng.choice(["chat", "doc", "rag"]),
                              arrival_ts=time.time())
                t0 = time.perf_counter(); g = mod.choose_gpu(req, states); times.append((time.perf_counter() - t0) * 1000)
                if hasattr(mod, "on_complete") and rng.random() < 0.5:   # keep the tracked requests realistic
                    mod.on_complete(str(rng.randint(max(0, i - 8), i)), g, 0, 0, 0)
            rows.append({"strategy": name, "nodes": k, "mean_ms": statistics.mean(times), "p99_ms": pct(times, .99)})
            print(f"{name:14s} {k:2d} nodes  mean {rows[-1]['mean_ms']:.4f} ms  p99 {rows[-1]['p99_ms']:.4f} ms")
    write_csv(out / "decision_time.csv", rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="results/runs")
    ap.add_argument("--out", default="results/analysis")
    ap.add_argument("--baseline", default="round_robin")
    ap.add_argument("--decision-time", action="store_true")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    if a.decision_time:
        decision_time(out)
    else:
        analyze(a.runs, out, a.baseline)


if __name__ == "__main__":
    main()
